import { Question, mockQuestions } from '@/lib/mockData';

const N8N_GENERATE_URL = '/api/generate';
const N8N_EVALUATE_URL = '/api/evaluate';

export async function generateQuestions(prompt: string, examType: 'mcq' | 'descriptive'): Promise<Question[]> {
  await new Promise((r) => setTimeout(r, 2500));
  return mockQuestions;
}

export async function evaluateAnswers(
  examId: string,
  answers: Record<string, string>,
  _images?: Record<string, File>
): Promise<{ marks: number; feedback: string }[]> {
  await new Promise((r) => setTimeout(r, 2000));
  return Object.keys(answers).map(() => ({
    marks: Math.floor(Math.random() * 3),
    feedback: 'Good attempt. Consider elaborating on key concepts.',
  }));
}

export async function loginUser(email: string, password: string, role: string) {
  await new Promise((r) => setTimeout(r, 800));
  return { token: 'mock-jwt-token', role };
}

export async function signupUser(name: string, username: string, email: string, password: string) {
  await new Promise((r) => setTimeout(r, 1000));
  return { id: crypto.randomUUID(), name, username, email, role: 'student' as const };
}
